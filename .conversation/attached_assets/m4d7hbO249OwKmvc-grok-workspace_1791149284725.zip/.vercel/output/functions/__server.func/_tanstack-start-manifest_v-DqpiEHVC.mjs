//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DqpiEHVC.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/history",
			"/learn"
		],
		preloads: ["/assets/index-tng3iJue.js", "/assets/jsx-runtime-Dk72oS4N.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-tng3iJue.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BF8ckHZG.js", "/assets/stats-DdK6g70O.js"]
	},
	"/history": {
		filePath: "/workspace/src/routes/history.tsx",
		children: void 0,
		preloads: ["/assets/history-Cyan9fPn.js", "/assets/stats-DdK6g70O.js"]
	},
	"/learn": {
		filePath: "/workspace/src/routes/learn.tsx",
		children: void 0,
		preloads: ["/assets/learn-BtmCr6UT.js"]
	}
} });
//#endregion
export { tsrStartManifest };
