import { o as __toESM } from "../_runtime.mjs";
import { J as require_react, Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as StatRow } from "./stats-BLq-cOjy.mjs";
import { l as Activity, n as ShieldCheck, s as ChevronDown } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B28epES3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var connectPocketSession = createServerFn({ method: "POST" }).validator((input) => {
	const ssid = typeof input?.ssid === "string" ? input.ssid.trim() : "";
	if (!ssid.startsWith("42") || !ssid.includes("\"auth\"") || !ssid.includes("\"session\"") || ssid.length > 4e3) throw new Error("Нужна полная строка вида 42[\"auth\",{\"session\":\"...\",\"isDemo\":1,\"uid\":0,\"platform\":2}]");
	return { ssid };
}).handler(createSsrRpc("f2f68f8306589da7f22df0dda1c3dd35b364be444b0e02d4c52ee6fa0f92c2d7"));
var readPocketSession = createServerFn({ method: "GET" }).handler(createSsrRpc("63ffd63852e6e29091021c4928e47597a9008cb520fdea51f118f3f9a664db27"));
function SessionConnect() {
	const [ssid, setSsid] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [balance, setBalance] = (0, import_react.useState)(null);
	const [demo, setDemo] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		readPocketSession().then((live) => {
			if (live.balance === null) return;
			setBalance(live.balance);
			setDemo(live.demo);
		});
	}, []);
	const submit = async () => {
		setBusy(true);
		setError("");
		try {
			const result = await connectPocketSession({ data: { ssid } });
			if (!result.ok || result.balance === null) {
				setError(result.error || "Баланс не пришёл");
				return;
			}
			setBalance(result.balance);
			setDemo(result.demo);
			setSsid("");
		} catch (cause) {
			setError(cause instanceof Error ? cause.message : "Не удалось подключиться");
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "panel rise rise-2 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold text-fg",
				children: "Баланс Pocket Option"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-relaxed text-muted",
				children: "Вставьте строку из сокета, которая начинается с 42[\"auth\". Заявки отсюда не отправляются."
			}),
			balance !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 font-mono text-3xl font-extrabold text-blue-soft",
				children: [
					"$",
					balance.toLocaleString("en-US", {
						minimumFractionDigits: 2,
						maximumFractionDigits: 2
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-sm font-semibold text-dim",
						children: demo ? "демо" : "реальный"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				value: ssid,
				spellCheck: false,
				autoComplete: "off",
				placeholder: "42[\"auth\",{\"session\":\"...\",\"isDemo\":1,\"uid\":0,\"platform\":2}]",
				onChange: (event) => setSsid(event.target.value),
				className: "field mt-3 h-24 resize-none px-3 py-2 font-mono text-xs"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn-prime mt-3",
				disabled: busy || ssid.trim().length < 20,
				onClick: () => void submit(),
				children: busy ? "Подключаем…" : "Подключить"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-loss",
				children: error
			}) : null
		]
	});
}
var risks = [
	"1",
	"2",
	"3",
	"5"
];
function BalanceCalculator() {
	const [open, setOpen] = (0, import_react.useState)(true);
	const [balance, setBalance] = (0, import_react.useState)("");
	const [risk, setRisk] = (0, import_react.useState)("2");
	const [plan, setPlan] = (0, import_react.useState)(false);
	const [saved, setSaved] = (0, import_react.useState)(false);
	const balanceNum = Number(balance) || 0;
	const riskNum = Number(risk) || 2;
	const trade = balanceNum * riskNum / 100;
	const steps = (0, import_react.useMemo)(() => {
		if (trade <= 0) return [];
		return [
			1,
			2,
			3,
			4
		].map((step) => {
			const amount = trade * 2 ** (step - 1);
			const loss = trade * (2 ** (step - 1) - 1);
			return {
				step,
				amount,
				loss,
				profit: amount * .85 - loss
			};
		});
	}, [trade]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "panel overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "flex w-full items-center justify-between px-4 py-4 text-left",
			onClick: () => setOpen((v) => !v),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-sm font-semibold text-fg",
				children: "Калькулятор риска"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-sm text-dim",
				children: "Сумма входа и план удвоения"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `size-4 text-muted transition-transform ${open ? "rotate-180" : ""}` })]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 px-4 pb-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm text-muted",
					children: ["Баланс, $", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "decimal",
						value: balance,
						placeholder: "1000",
						onChange: (event) => {
							setBalance(event.target.value.replace(/[^\d.]/g, ""));
							setSaved(false);
						},
						className: "field mt-2 h-12 px-3 font-mono"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm text-muted",
					children: "Риск на сделку"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2",
					children: risks.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: `chip flex-1 ${risk === item ? "on" : ""}`,
						onClick: () => setRisk(item),
						children: [item, "%"]
					}, item))
				})] }),
				balanceNum > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-blue/10 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Рекомендуемая сумма"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 font-mono text-3xl font-extrabold text-blue-soft",
							children: ["$", trade.toFixed(2)]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-dim",
							children: [
								riskNum,
								"% от $",
								balanceNum.toFixed(0)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn-prime mt-3",
							onClick: () => {
								localStorage.setItem("last_trade_amount", trade.toFixed(2));
								setSaved(true);
							},
							children: saved ? "Сумма сохранена" : "Сохранить сумму"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-start gap-2 text-sm text-dim",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "mt-0.5 size-4 shrink-0 text-blue-soft" }), "Введите баланс, чтобы посчитать вход."]
				}),
				balanceNum > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `chip ${plan ? "on" : ""}`,
					onClick: () => setPlan((v) => !v),
					children: "План удвоения"
				}), plan ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-2",
					children: [steps.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-4 gap-2 rounded-xl bg-white/3 px-3 py-2 text-center font-mono text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-blue-soft",
								children: row.step === 1 ? "Вход" : `×${2 ** (row.step - 1)}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["$", row.amount.toFixed(2)] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-loss",
								children: row.loss > 0 ? `-$${row.loss.toFixed(2)}` : "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-win",
								children: ["+$", row.profit.toFixed(2)]
							})
						]
					}, row.step)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed text-dim",
						children: "Удвоение может перекрыть минус, но быстро съедает депозит. Дальше третьего шага лучше не идти."
					})]
				}) : null] }) : null
			]
		}) : null]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rise",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-4xl font-bold tracking-tight text-fg",
					children: "Сигналы"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-base leading-relaxed text-muted",
					children: "Активные направления, счётчики дня и калькулятор риска."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rise rise-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatRow, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[1.1fr_0.9fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "panel rise rise-3 flex min-h-48 flex-col items-center justify-center px-6 py-10 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "size-6 text-blue-soft" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-base font-semibold text-fg",
							children: "Активных сигналов нет"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 max-w-sm text-sm text-dim",
							children: "Когда появятся, они будут в этом списке."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SessionConnect, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BalanceCalculator, {})]
				})]
			})
		]
	});
}
//#endregion
export { Home as component };
