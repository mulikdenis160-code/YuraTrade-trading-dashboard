import { Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stats-BLq-cOjy.js
var import_jsx_runtime = require_jsx_runtime();
var items = [
	{
		label: "Сигналов",
		value: "0",
		tone: "text-fg"
	},
	{
		label: "Побед",
		value: "0",
		tone: "text-win"
	},
	{
		label: "Поражений",
		value: "0",
		tone: "text-loss"
	},
	{
		label: "Успешность",
		value: "0%",
		tone: "text-blue-soft"
	}
];
function StatRow() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel px-3 py-3 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `font-mono text-2xl font-extrabold ${item.tone}`,
				children: item.value
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs font-semibold tracking-wide text-dim uppercase",
				children: item.label
			})]
		}, item.label))
	});
}
//#endregion
export { StatRow as t };
