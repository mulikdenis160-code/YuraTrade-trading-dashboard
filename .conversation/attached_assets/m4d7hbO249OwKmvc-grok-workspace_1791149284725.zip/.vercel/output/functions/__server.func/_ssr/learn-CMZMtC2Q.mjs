import { o as __toESM } from "../_runtime.mjs";
import { J as require_react, Y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learn-CMZMtC2Q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var lessons = [
	{
		id: "deal",
		title: "Как устроена сделка",
		minutes: 4,
		lead: "Бинарный контракт — это ставка на направление цены к фиксированному времени, а не покупка актива.",
		blocks: [
			{
				type: "p",
				text: "Вы выбираете пару, срок и направление: цена будет выше или ниже цены входа, когда таймер дойдёт до нуля. Брокер заранее показывает выплату. Если направление угадано, возвращается ставка плюс процент. Если нет — ставка сгорает. Ничья бывает, когда цена закрытия совпала с ценой входа: обычно деньги возвращают."
			},
			{
				type: "h",
				text: "Что вы контролируете"
			},
			{
				type: "list",
				items: [
					"Пару. Тот же тикер, что открыт на графике.",
					"Срок. В этом приложении ориентир — 1, 3 и 5 минут.",
					"Направление. Вверх или вниз от цены в момент входа.",
					"Сумму. Её считает калькулятор риска, не «чуть-чуть доберу»."
				]
			},
			{
				type: "h",
				text: "Чего вы не контролируете"
			},
			{
				type: "p",
				text: "Следующую свечу, задержку клика и то, успеет ли цена дойти до уровня до экспирации. Сигнал — это подсказка, не приказ. Сделку открываете вы, в своём кабинете, своими руками."
			},
			{
				type: "note",
				text: "Приложение не входит в сделки и не хранит пароль Pocket Option. Девятизначный ID нужен только как метка сессии в этом браузере."
			}
		]
	},
	{
		id: "card",
		title: "Как читать сигнал",
		minutes: 4,
		lead: "Карточка должна отвечать на четыре вопроса до того, как вы нажмёте кнопку у брокера.",
		blocks: [
			{
				type: "list",
				items: [
					"Пара. Тот же тикер, что на графике.",
					"Направление. Вверх — цена к экспирации выше входа. Вниз — ниже.",
					"Срок. 1 минута не равно 5 минут: это другой шум и другая ошибка входа.",
					"Цена входа. Сверяйте с графиком. Если цена уже ушла, сигнал опоздал."
				]
			},
			{
				type: "h",
				text: "Порядок, который не путает"
			},
			{
				type: "p",
				text: "Сначала график, потом карточка, потом сумма. Если открыть сделку и только потом смотреть, почему она появилась, вы торгуете скорость, а не идею. На коротком сроке 5–10 секунд опоздания часто съедают весь смысл входа."
			},
			{
				type: "h",
				text: "Когда сигнал лучше пропустить"
			},
			{
				type: "list",
				items: [
					"Пара на графике не совпадает с карточкой.",
					"До конца свечи осталось меньше времени, чем нужно на спокойный вход.",
					"Вы уже в серии из трёх минусов и хотите «отыграться».",
					"Выплата на паре заметно ниже той, под которую вы считали риск."
				]
			}
		]
	},
	{
		id: "expiry",
		title: "Экспирация",
		minutes: 4,
		lead: "Срок — это не «подождать подольше», а другое правило победы.",
		blocks: [
			{
				type: "rows",
				headers: [
					"Срок",
					"Характер",
					"Типичная ошибка"
				],
				rows: [
					[
						"1 мин",
						"Много шума, мало времени на вход",
						"Кликнуть в последнюю секунду"
					],
					[
						"3 мин",
						"Компромисс между шумом и ожиданием",
						"Менять срок уже после входа"
					],
					[
						"5 мин",
						"Чуть спокойнее, дольше держит ошибку",
						"Ставить как на минутке, только крупнее"
					]
				]
			},
			{
				type: "p",
				text: "Экспирация фиксируется в момент открытия. Продлить её нельзя. Если вы заходили на 1 минуту, а через 20 секунд «поняли», что надо было на 5, это уже другая сделка и новый риск, а не исправление старой."
			},
			{
				type: "h",
				text: "Время суток"
			},
			{
				type: "p",
				text: "На коротких сроках важнее не новость часа, а то, есть ли сейчас направленное движение или пила. Пила на 1 минуте даёт череду случайных исходов даже при аккуратном входе. Если пять свечей подряд без направления, лучше не торговать этот отрезок, чем собирать статистику убытков."
			}
		]
	},
	{
		id: "payout",
		title: "Выплата и безубыток",
		minutes: 5,
		lead: "50% побед при выплате 80% — это минус. Считать нужно не «угадал или нет», а деньги.",
		blocks: [
			{
				type: "p",
				text: "Формула порога: доля побед, после которой сессия не в минусе, равна 1 / (1 + выплата). Выплата берётся долей: 92% — это 0,92. Для 92% порог около 52%. Для 80% — около 56%. Для 70% — около 59%."
			},
			{
				type: "rows",
				headers: [
					"Выплата",
					"Порог побед",
					"10 сделок по $10 при 50%"
				],
				rows: [
					[
						"92%",
						"52%",
						"5×19,2 − 5×10 = −$4"
					],
					[
						"80%",
						"56%",
						"5×18 − 5×10 = −$10"
					],
					[
						"70%",
						"59%",
						"5×17 − 5×10 = −$15"
					]
				]
			},
			{
				type: "p",
				text: "Пример для 92%. Пять побед приносят 5 × 10 × 0,92 = $46 сверх возврата ставки, пять поражений забирают $50. Итог −$4 при честной монете. Чтобы быть в небольшом плюсе, нужно стабильно выше порога, и ещё покрыть проскальзывание входа."
			},
			{
				type: "note",
				text: "Выплата на экране брокера важнее любой «успешности» в карточке. Если процент упал, пересчитайте порог до следующей сделки."
			}
		]
	},
	{
		id: "risk",
		title: "Размер ставки",
		minutes: 5,
		lead: "Калькулятор на главной делит баланс на риск. Это потолок на одну сделку, не цель.",
		blocks: [
			{
				type: "p",
				text: "1% от депозита на вход оставляет запас на длинную серию минусов. 2% — обычный потолок для короткой сессии. 5% уже означает, что шесть поражений подряд снимают больше четверти счёта без всякого удвоения."
			},
			{
				type: "h",
				text: "Серия"
			},
			{
				type: "p",
				text: "Десять независимых сделок с шансом около 50/50 довольно часто дают 3–4 минуса подряд. Это не «рынок против вас» и не знак удваивать. Это обычная очередь. Заранее решите, после скольких минусов сессия закрывается. Нормальный стоп — 3 поражения или минус в день, который вы готовы забыть."
			},
			{
				type: "h",
				text: "Удвоение"
			},
			{
				type: "list",
				items: [
					"Шаг 1: обычная ставка.",
					"Шаг 2: уже две ставки. Проигрыш забирает тройную базу.",
					"Шаг 3: четыре ставки. Общий минус — семь баз.",
					"Шаг 4: восемь ставок. Один такой круг может съесть дневной лимит."
				]
			},
			{
				type: "note",
				text: "План удвоения в калькуляторе показан, чтобы увидеть скорость убытка, а не как рекомендацию его включать. Дальше третьего шага таблица краснеет не для красоты."
			}
		]
	},
	{
		id: "stats",
		title: "Почему процент побед врёт",
		minutes: 4,
		lead: "93% в чужом отчёте почти ничего не говорят, пока не видно поражений и тех же условий входа.",
		blocks: [
			{
				type: "list",
				items: [
					"В отбор попадают только удачные часы.",
					"Поражения пишут в другом канале или не пишут.",
					"Срок и выплата в отчёте не совпадают с вашими.",
					"Мало сделок: 13 побед и 1 поражение — это ещё не система.",
					"Считают по одному графику, а сделку закрывают по другому."
				]
			},
			{
				type: "p",
				text: "Своя статистика честнее. Считайте деньги за день, а не только зелёные галочки. 18 побед и 12 поражений при выплате 80% могут быть минусом. Нули в счётчиках значат «сделок ещё не было», а не идеальный день."
			},
			{
				type: "h",
				text: "Минимум, который имеет смысл"
			},
			{
				type: "p",
				text: "Оценивайте отрезок от 30 закрытых сделок с одной и той же суммой, одним сроком и записанной выплатой. До этого любой процент — шум. Если после 30 сделок вы ниже порога безубытка, правило не работает, даже если первые десять выглядели отлично."
			}
		]
	},
	{
		id: "session",
		title: "Как проходит сессия",
		minutes: 5,
		lead: "Короткая сессия с концом лучше, чем «ещё одна, и хватит».",
		blocks: [
			{
				type: "h",
				text: "До"
			},
			{
				type: "list",
				items: [
					"Проверить ID и что открыт нужный счёт, не чужой.",
					"Записать баланс и выбрать риск 1–2%.",
					"Посмотреть выплату на тех парах, которые собираетесь трогать.",
					"Назначить стоп: три минуса или фиксированная сумма."
				]
			},
			{
				type: "h",
				text: "Во время"
			},
			{
				type: "list",
				items: [
					"Одна сделка за раз. Вторая не лечит первую.",
					"Не менять сумму после поражения.",
					"Пропускать сигнал, если не успели сверить цену.",
					"Держать срок тем, что выбран до клика."
				]
			},
			{
				type: "h",
				text: "После"
			},
			{
				type: "p",
				text: "Запишите число сделок, побед, поражений, выплату и итог в деньгах. Если день закрыт в минус внутри лимита — это выполненное правило, а не повод открывать ночную сессию. Завтрашний баланс не обязан отбивать сегодняшний."
			}
		]
	},
	{
		id: "mistakes",
		title: "Ошибки, которые повторяют все",
		minutes: 5,
		lead: "Большая часть минуса на коротких сроках — не «плохой сигнал», а поведение после него.",
		blocks: [{
			type: "list",
			items: [
				"Отыгрыш. После минуса ставка растёт, потому что «должно отбить».",
				"Чужой винрейт. Канал показывает 90%, ваш день — 48%.",
				"Смешение пар. Сигнал на GBP/JPY, клик на EUR/USD, потому что график уже открыт.",
				"Поздний вход. Свеча почти закрылась, направление уже отыграно.",
				"Смена срока на ходу.",
				"Торговля без стопа сессии.",
				"Вера, что короткая свеча повторит учебник с дневного графика.",
				"Пароль от кабинета в чужом боте. Здесь он не нужен и никому его не отдавайте."
			]
		}, {
			type: "note",
			text: "Если поймали себя на фразе «последняя, и всё», сессия уже закончилась. Закройте график до этой сделки, не после."
		}]
	},
	{
		id: "glossary",
		title: "Словарь",
		minutes: 4,
		lead: "Короткие определения теми словами, которые встречаются в интерфейсе.",
		blocks: [{
			type: "rows",
			headers: [
				"Слово",
				"Значение",
				"Не путать с"
			],
			rows: [
				[
					"CALL / вверх",
					"Ставка, что цена закроется выше входа",
					"Покупкой актива"
				],
				[
					"PUT / вниз",
					"Ставка, что цена закроется ниже входа",
					"Продажей в шорт на бирже"
				],
				[
					"Экспирация",
					"Момент, когда контракт фиксируют",
					"Сроком удержания акции"
				],
				[
					"Выплата",
					"Процент сверху ставки при победе",
					"Прибылью всей сессии"
				],
				[
					"Порог",
					"Доля побед, чтобы не быть в минусе",
					"Красивым процентом канала"
				],
				[
					"Ничья",
					"Цена закрытия равна входу",
					"Победой"
				],
				[
					"ID",
					"9 цифр профиля Pocket Option",
					"Паролем или номером карты"
				]
			]
		}]
	}
];
var quiz = [
	{
		q: "Выплата 80%. Какая доля побед нужна, чтобы не терять на дистанции?",
		options: [
			"Ровно 50%",
			"Около 56%",
			"Около 80%",
			"Любая выше 40%"
		],
		answer: 1,
		why: "Порог = 1 / (1 + 0,80) ≈ 55,6%. Пятьдесят на пятьдесят при такой выплате убыточны."
	},
	{
		q: "Сигнал на GBP/JPY, а на графике открыт EUR/USD. Что делать?",
		options: [
			"Входить, направление то же",
			"Пропустить, пока пара не та",
			"Входить меньшей суммой",
			"Перевернуть направление"
		],
		answer: 1,
		why: "Пара в сигнале и пара на графике должны совпасть. Иначе это уже другая сделка."
	},
	{
		q: "После двух поражений рука тянется удвоить. Зачем в калькуляторе таблица шагов?",
		options: [
			"Чтобы показать, как быстро растёт убыток",
			"Чтобы обязательно включить мартингейл",
			"Чтобы брокер повысил выплату",
			"Чтобы обойти лимит сессии"
		],
		answer: 0,
		why: "Таблица считает, сколько баз сгорит на третьем и четвёртом шаге. Это предупреждение, не стратегия."
	},
	{
		q: "Канал пишет 93% за утро, 13 побед и 1 поражение. Этого достаточно?",
		options: [
			"Да, можно копировать весь день",
			"Нет: выборка крошечная и поражения легко прячут",
			"Да, если выплата выше 50%",
			"Нет, только если нет демо"
		],
		answer: 1,
		why: "Четырнадцать сделок не отличают удачу от правила. Смотрите полный список и свои деньги, не чужой заголовок."
	},
	{
		q: "Что приложение просит для входа?",
		options: [
			"Почту и пароль кабинета",
			"Только 9 цифр ID, без регистрации",
			"Номер карты",
			"Код из SMS брокера"
		],
		answer: 1,
		why: "Регистрации нет. Пароль Pocket Option здесь не нужен и его некуда вводить."
	},
	{
		q: "Сделка открыта на 1 минуту. Через 15 секунд кажется, что лучше было на 5. Как правильно?",
		options: [
			"Это уже новая ставка, старую не продлить",
			"Срок сам перенесётся",
			"Можно отменить без потери",
			"Нужно удвоить и переоткрыть"
		],
		answer: 0,
		why: "Экспирация фиксируется при входе. Вторая сделка — отдельный риск, а не правка первой."
	}
];
var DONE_KEY = "vprime_learn_done";
function readDone() {
	try {
		const raw = JSON.parse(localStorage.getItem(DONE_KEY) || "[]");
		return Array.isArray(raw) ? raw.filter((id) => typeof id === "string") : [];
	} catch {
		return [];
	}
}
function LearnPage() {
	const [current, setCurrent] = (0, import_react.useState)(lessons[0].id);
	const [done, setDone] = (0, import_react.useState)([]);
	const [picked, setPicked] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		setDone(readDone());
	}, []);
	const lesson = lessons.find((item) => item.id === current) ?? lessons[0];
	const score = quiz.filter((item, index) => picked[index] === item.answer).length;
	const answered = Object.keys(picked).length;
	const mark = () => {
		const next = done.includes(lesson.id) ? done : [...done, lesson.id];
		setDone(next);
		localStorage.setItem(DONE_KEY, JSON.stringify(next));
		const following = lessons[lessons.findIndex((item) => item.id === lesson.id) + 1];
		if (following) setCurrent(following.id);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rise",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold tracking-[0.16em] text-blue-soft uppercase",
						children: "Курс"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 text-4xl font-bold tracking-tight text-fg",
						children: "Обучение"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 max-w-2xl text-base leading-relaxed text-muted",
						children: [
							"Девять коротких тем и проверка. Это разбор правил и риска, не обещание дохода. Прочитано ",
							done.length,
							" из ",
							lessons.length,
							"."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-4 lg:grid-cols-[16rem_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "rise rise-2 flex gap-2 overflow-x-auto pb-1 lg:flex-col lg:overflow-visible",
					children: lessons.map((item, index) => {
						const on = item.id === lesson.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setCurrent(item.id),
							className: `shrink-0 rounded-2xl px-3 py-2 text-left lg:w-full ${on ? "bg-blue/10 text-blue-soft" : "text-muted hover:bg-white/4"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-sm font-semibold",
								children: [
									index + 1,
									". ",
									item.title
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-0.5 block text-xs text-dim",
								children: [
									item.minutes,
									" мин",
									done.includes(item.id) ? " · прочитано" : ""
								]
							})]
						}, item.id);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "panel rise rise-3 p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs font-semibold tracking-wide text-dim uppercase",
							children: [lesson.minutes, " минут"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 text-2xl font-bold tracking-tight text-fg",
							children: lesson.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-base leading-relaxed text-muted",
							children: lesson.lead
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 space-y-4",
							children: lesson.blocks.map((block, index) => {
								if (block.type === "h") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "pt-2 text-lg font-semibold text-fg",
									children: block.text
								}, index);
								if (block.type === "p") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-base leading-relaxed text-fg/90",
									children: block.text
								}, index);
								if (block.type === "note") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "rounded-2xl bg-blue/10 px-4 py-3 text-sm leading-relaxed text-muted",
									children: block.text
								}, index);
								if (block.type === "list") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "space-y-2",
									children: block.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex gap-3 text-sm leading-relaxed text-fg/90",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 size-1.5 shrink-0 rounded-full bg-blue-soft" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
									}, item))
								}, index);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "hidden overflow-x-auto sm:block",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
										className: "w-full text-left text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
											className: "text-xs tracking-wide text-dim uppercase",
											children: block.headers.map((header) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-2 py-2 font-semibold",
												children: header
											}, header))
										}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: block.rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
											className: "border-t border-white/6",
											children: row.map((cell) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-2 py-2 align-top text-fg/90",
												children: cell
											}, cell))
										}, row.join())) })]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-2 sm:hidden",
									children: block.rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-2xl bg-white/4 px-3 py-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-semibold text-fg",
												children: row[0]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-1 text-sm leading-relaxed text-muted",
												children: [
													block.headers[1],
													": ",
													row[1]
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-1 text-sm leading-relaxed text-muted",
												children: [
													block.headers[2],
													": ",
													row[2]
												]
											})
										]
									}, row.join()))
								})] }, index);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn-prime mt-6",
							onClick: mark,
							children: done.includes(lesson.id) ? "Уже отмечено" : "Дальше"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel rise rise-4 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-bold tracking-tight text-fg",
						children: "Проверка"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: answered === 0 ? "Шесть вопросов по темам выше." : `Верно ${score} из ${quiz.length}.`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-5 space-y-5",
						children: quiz.map((item, index) => {
							const choice = picked[index];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-base font-semibold text-fg",
									children: [
										index + 1,
										". ",
										item.q
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 grid gap-2 sm:grid-cols-2",
									children: item.options.map((option, optionIndex) => {
										const selected = choice === optionIndex;
										const show = choice !== void 0;
										const good = show && optionIndex === item.answer;
										const bad = show && selected && optionIndex !== item.answer;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: show,
											onClick: () => setPicked((prev) => ({
												...prev,
												[index]: optionIndex
											})),
											className: `rounded-2xl px-3 py-3 text-left text-sm ${good ? "bg-win/15 text-win" : bad ? "bg-loss/15 text-loss" : "bg-white/4 text-fg hover:bg-white/8"}`,
											children: option
										}, option);
									})
								}),
								choice !== void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted",
									children: item.why
								}) : null
							] }, item.q);
						})
					})
				]
			})
		]
	});
}
//#endregion
export { LearnPage as component };
