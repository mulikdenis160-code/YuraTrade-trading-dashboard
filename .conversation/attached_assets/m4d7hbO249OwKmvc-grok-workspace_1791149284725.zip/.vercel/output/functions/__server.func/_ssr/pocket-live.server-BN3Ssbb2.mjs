import { t as wrapper_default } from "../_libs/ws.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pocket-live.server-BN3Ssbb2.js
var DEMO_URL = "wss://demo-api-eu.po.market/socket.io/?EIO=4&transport=websocket";
var REAL_URL = "wss://api-eu.po.market/socket.io/?EIO=4&transport=websocket";
var state = {
	connected: false,
	balance: null,
	demo: null,
	uid: null,
	error: ""
};
var socket = null;
var expectBalance = false;
function textOf(data) {
	if (typeof data === "string") return data;
	if (Buffer.isBuffer(data)) return data.toString("utf8");
	if (data instanceof ArrayBuffer) return Buffer.from(data).toString("utf8");
	return Buffer.concat(data).toString("utf8");
}
function readNumber(source, key) {
	const match = source.match(new RegExp(`"${key}"\\s*:\\s*(-?\\d+(?:\\.\\d+)?)`));
	return match ? Number(match[1]) : null;
}
function pocketLiveState() {
	return { ...state };
}
function openPocketSession(ssid) {
	const demo = /"isDemo"\s*:\s*1/.test(ssid);
	state.uid = readNumber(ssid, "uid");
	state.demo = demo;
	state.error = "";
	state.connected = false;
	if (socket) {
		try {
			socket.removeAllListeners();
			socket.terminate();
		} catch {}
		socket = null;
	}
	const next = new wrapper_default(demo ? DEMO_URL : REAL_URL, {
		headers: {
			Origin: "https://pocketoption.com",
			"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
		},
		handshakeTimeout: 8e3
	});
	socket = next;
	expectBalance = false;
	return new Promise((resolve) => {
		let settled = false;
		const finish = () => {
			if (settled) return;
			settled = true;
			clearTimeout(timer);
			resolve(pocketLiveState());
		};
		const timer = setTimeout(() => {
			state.error = "Сервер не прислал баланс. Строка сессии могла устареть.";
			finish();
		}, 12e3);
		next.on("error", () => {
			state.connected = false;
			state.error = "Не удалось открыть соединение с Pocket Option.";
			finish();
		});
		next.on("close", () => {
			if (socket === next) {
				state.connected = false;
				socket = null;
			}
		});
		next.on("message", (data) => {
			const message = textOf(data);
			if (message.startsWith("0") && message.includes("sid")) {
				next.send("40");
				return;
			}
			if (message === "2") {
				next.send("3");
				return;
			}
			if (message.startsWith("40") && message.includes("sid")) {
				next.send(ssid);
				return;
			}
			if (message.includes("NotAuthorized")) {
				state.connected = false;
				state.error = "Сессия не принята. Нужна свежая строка из сокета.";
				finish();
				return;
			}
			if (message.includes("successauth")) state.connected = true;
			if (message.includes("successupdateBalance")) expectBalance = true;
			if (!expectBalance || message.length > 400) return;
			const balance = readNumber(message, "balance");
			if (balance === null) return;
			const flag = readNumber(message, "isDemo");
			state.balance = balance;
			state.demo = flag === null ? demo : flag === 1;
			state.connected = true;
			state.error = "";
			finish();
		});
	});
}
//#endregion
export { openPocketSession, pocketLiveState };
