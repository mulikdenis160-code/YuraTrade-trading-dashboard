import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pocket-live-hPX8M2og.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var connectPocketSession_createServerFn_handler = createServerRpc({
	id: "f2f68f8306589da7f22df0dda1c3dd35b364be444b0e02d4c52ee6fa0f92c2d7",
	name: "connectPocketSession",
	filename: "src/lib/pocket-live.ts"
}, (opts) => connectPocketSession.__executeServer(opts));
var connectPocketSession = createServerFn({ method: "POST" }).validator((input) => {
	const ssid = typeof input?.ssid === "string" ? input.ssid.trim() : "";
	if (!ssid.startsWith("42") || !ssid.includes("\"auth\"") || !ssid.includes("\"session\"") || ssid.length > 4e3) throw new Error("Нужна полная строка вида 42[\"auth\",{\"session\":\"...\",\"isDemo\":1,\"uid\":0,\"platform\":2}]");
	return { ssid };
}).handler(connectPocketSession_createServerFn_handler, async ({ data }) => {
	const { openPocketSession } = await import("./pocket-live.server-BN3Ssbb2.mjs");
	const live = await openPocketSession(data.ssid);
	return {
		ok: live.balance !== null && !live.error,
		balance: live.balance,
		demo: live.demo,
		error: live.error
	};
});
var readPocketSession_createServerFn_handler = createServerRpc({
	id: "63ffd63852e6e29091021c4928e47597a9008cb520fdea51f118f3f9a664db27",
	name: "readPocketSession",
	filename: "src/lib/pocket-live.ts"
}, (opts) => readPocketSession.__executeServer(opts));
var readPocketSession = createServerFn({ method: "GET" }).handler(readPocketSession_createServerFn_handler, async () => {
	const { pocketLiveState } = await import("./pocket-live.server-BN3Ssbb2.mjs");
	const live = pocketLiveState();
	return {
		connected: live.connected,
		balance: live.balance,
		demo: live.demo
	};
});
//#endregion
export { connectPocketSession_createServerFn_handler, readPocketSession_createServerFn_handler };
