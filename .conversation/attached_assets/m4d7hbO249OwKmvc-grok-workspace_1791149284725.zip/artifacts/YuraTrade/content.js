(() => {
  let wins = 0, losses = 0, currentPair = "—";
  let streak = 0, bestStreak = 0, sessionStart = Date.now();
  let dayStartBalance = null;
  let dayCurrentBalance = null;
  let balanceDayKey = "";

  const MIN_W = 220, MIN_H = 340;
  const MAX_W = 420, MAX_H = 680;
  const BASE_W = 280, BASE_H = 392;

  const DEFAULTS = {
    opacity: 94,
    blur: 22,
    showClock: true,
    showPair: true,
    showBar: true,
    showWinrate: true,
    showStreak: true,
    showSession: false,
    lockPosition: false,
    sound: false,
    clickSound: true,
    confirmReset: true,
    autoHideIdle: false,
    idleMinutes: 5,
    theme: "neon",
    counterStep: 1,
  };

  let settings = { ...DEFAULTS };
  let idleTimer = null;

  function todayKey() {
    const n = new Date();
    return `${n.getFullYear()}-${pad(n.getMonth() + 1)}-${pad(n.getDate())}`;
  }

  function parseMoney(raw) {
    if (raw == null) return null;
    let t = String(raw).replace(/\s/g, "").replace(/[^\d.,-]/g, "");
    if (!t || t.includes("*")) return null;
    if (t.includes(",") && t.includes(".")) t = t.replace(/,/g, "");
    else if (t.includes(",") && !t.includes(".")) {
      const parts = t.split(",");
      if (parts.length === 2 && parts[1].length <= 2) t = parts[0].replace(/\./g, "") + "." + parts[1];
      else t = t.replace(/,/g, "");
    }
    const n = parseFloat(t);
    return Number.isFinite(n) ? n : null;
  }

  function formatMoney(n) {
    if (n == null || !Number.isFinite(n)) return "—";
    return n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function loadBalanceDay() {
    try {
      const raw = localStorage.getItem("yura_trade_day_balance");
      if (!raw) return;
      const saved = JSON.parse(raw);
      if (saved && saved.day === todayKey() && typeof saved.start === "number") {
        balanceDayKey = saved.day;
        dayStartBalance = saved.start;
        dayCurrentBalance = typeof saved.current === "number" ? saved.current : saved.start;
      }
    } catch (_) {}
  }

  function saveBalanceDay() {
    try {
      localStorage.setItem("yura_trade_day_balance", JSON.stringify({
        day: balanceDayKey || todayKey(),
        start: dayStartBalance,
        current: dayCurrentBalance
      }));
    } catch (_) {}
  }

  function readPlatformBalance() {
    const el = document.querySelector(".js-balance-real-USD, span.js-hd.js-balance-real-USD");
    if (!el) return null;
    const shown = el.getAttribute("data-hd-show");
    const text = (el.textContent || "").trim();
    const raw = (shown && !shown.includes("*")) ? shown : (!text.includes("*") ? text : shown);
    return parseMoney(raw);
  }

  function tickBalance() {
    const key = todayKey();
    const bal = readPlatformBalance();
    if (balanceDayKey !== key) {
      balanceDayKey = key;
      dayStartBalance = bal;
      dayCurrentBalance = bal;
      if (bal != null) saveBalanceDay();
      refreshBalance();
      return;
    }
    if (bal == null) {
      refreshBalance();
      return;
    }
    if (dayStartBalance == null) dayStartBalance = bal;
    dayCurrentBalance = bal;
    saveBalanceDay();
    refreshBalance();
  }

  function refreshBalance() {
    const startEl = document.getElementById("tl-bal-start");
    const nowEl = document.getElementById("tl-bal-now");
    const deltaEl = document.getElementById("tl-bal-delta");
    if (!startEl || !nowEl || !deltaEl) return;
    const capEl = document.getElementById("tl-bal-caption");
    startEl.textContent = formatMoney(dayStartBalance);
    nowEl.textContent = formatMoney(dayCurrentBalance);
    if (dayStartBalance == null || dayCurrentBalance == null) {
      if (capEl) capEl.textContent = "Чистый заработок";
      deltaEl.textContent = "—";
      deltaEl.style.color = "";
      return;
    }
    const d = dayCurrentBalance - dayStartBalance;
    const sign = d > 0 ? "+" : d < 0 ? "−" : "";
    if (capEl) capEl.textContent = d < 0 ? "Убыток" : "Чистый заработок";
    deltaEl.textContent = `${sign}${formatMoney(Math.abs(d))} $`;
    deltaEl.style.color = d > 0 ? "#00e99b" : d < 0 ? "#ff4d6a" : "#8b9ab0";
  }


  function currentDayProfit() {
    if (dayStartBalance == null || dayCurrentBalance == null) return null;
    return dayCurrentBalance - dayStartBalance;
  }

  function applyDayProfit(raw) {
    const t = String(raw).trim().replace(/\s/g, "").replace(",", ".");
    if (!t || t === "-" || t === "+") return false;
    const profit = parseFloat(t);
    if (!Number.isFinite(profit)) return false;
    const key = todayKey();
    balanceDayKey = key;
    if (dayCurrentBalance == null) {
      const live = readPlatformBalance();
      dayCurrentBalance = live != null ? live : 0;
    }
    dayStartBalance = dayCurrentBalance - profit;
    saveBalanceDay();
    refreshBalance();
    return true;
  }

  function loadSettings() {
    try {
      const raw = localStorage.getItem("yura_trade_cfg");
      if (raw) settings = { ...DEFAULTS, ...JSON.parse(raw) };
    } catch (_) {}
    loadBalanceDay();
    try {
      const stats = localStorage.getItem("yura_trade_stats");
      if (stats) {
        const s = JSON.parse(stats);
        wins = s.wins || 0;
        losses = s.losses || 0;
        bestStreak = s.bestStreak || 0;
        streak = s.streak || 0;
      }
    } catch (_) {}
  }

  function saveSettings() {
    try { localStorage.setItem("yura_trade_cfg", JSON.stringify(settings)); } catch (_) {}
  }

  function saveStats() {
    try {
      localStorage.setItem("yura_trade_stats", JSON.stringify({
        wins, losses, streak, bestStreak
      }));
    } catch (_) {}
  }

  function pad(n) { return String(n).padStart(2, "0"); }
  function getUTCOffset() {
    const o = -new Date().getTimezoneOffset() / 60;
    return (o >= 0 ? "+" : "") + o;
  }
  function formatTime() {
    const n = new Date();
    return `${pad(n.getHours())}:${pad(n.getMinutes())}:${pad(n.getSeconds())} UTC${getUTCOffset()}`;
  }
  function formatSession() {
    const sec = Math.floor((Date.now() - sessionStart) / 1000);
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    if (h > 0) return `${h}h ${pad(m)}m`;
    return `${m}m ${pad(s)}s`;
  }
  function winrate() {
    const t = wins + losses;
    if (!t) return "0.0% (0/0)";
    return `${((wins / t) * 100).toFixed(1)}% (${wins}/${t})`;
  }
  function winrateColor() {
    const t = wins + losses;
    if (!t) return "#8b9ab0";
    const p = (wins / t) * 100;
    return p >= 70 ? "#00e99b" : p >= 50 ? "#f0c040" : "#ff4d6a";
  }

  let audioCtx = null;
  function playTone(freq, dur) {
    if (!settings.clickSound && !settings.sound) return;
    try {
      if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.connect(g);
      g.connect(audioCtx.destination);
      o.frequency.value = freq;
      o.type = "sine";
      g.gain.setValueAtTime(0.1, audioCtx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + dur);
      o.start();
      o.stop(audioCtx.currentTime + dur);
    } catch (_) {}
  }

  const PAIR_SELECTORS = [
    ".pair", "div.pair", ".pair-number-wrap .pair", ".currencies-block .pair",
    '[class*="symbol-name"]', '[class*="asset-name"]', '[class*="instrument-name"]',
    '[class*="pair-name"]', '[class*="selected-asset"] [class*="name"]',
    '[class*="active-asset"] span', ".symbol .name", ".asset .name",
    ".trade-panel__asset-name", ".chart-header__asset-name", "#asset-name",
    '[data-test="asset-name"]',
  ];

  function detectPair() {
    for (const sel of PAIR_SELECTORS) {
      const el = document.querySelector(sel);
      if (el) {
        const t = el.textContent.trim();
        if (t && t.length > 2) return t.toUpperCase();
      }
    }
    const m = document.title.match(/([A-Z]{3}\/[A-Z]{3}(?:\s+OTC)?)/i);
    return m ? m[1].toUpperCase() : null;
  }

  function fitPairText(el) {
    if (!el || !el.parentElement) return;
    const maxW = el.parentElement.offsetWidth - 10;
    let size = 15;
    el.style.fontSize = size + "px";
    while (el.scrollWidth > maxW && size > 9) {
      size -= 0.5;
      el.style.fontSize = size + "px";
    }
  }

  function startPairWatcher() {
    const update = () => {
      if (!settings.showPair) return;
      const pair = detectPair();
      if (pair && pair !== currentPair) {
        currentPair = pair;
        const el = document.getElementById("tl-pair-name");
        if (el) {
          el.classList.remove("tl-pair-in", "tl-pair-out");
          void el.offsetWidth;
          el.classList.add("tl-pair-out");
          setTimeout(() => {
            el.textContent = currentPair;
            el.classList.remove("tl-pair-out");
            el.classList.add("tl-pair-in");
            fitPairText(el);
          }, 200);
        }
      }
    };
    setInterval(update, 900);
    new MutationObserver(update).observe(document.body, {
      subtree: true, childList: true, characterData: true,
    });
  }

  // Soft gradient blobs only — no particles / stars
  function initBg(overlay) {
    const canvas = overlay.querySelector("#tl-canvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    canvas.width = BASE_W;
    canvas.height = BASE_H;
    let t = 0;
    const blobs = [
      { x: 0.18, y: 0.12, r: 120, h: 215, s: 0.0004 },
      { x: 0.78, y: 0.22, r: 100, h: 255, s: 0.0005 },
      { x: 0.42, y: 0.82, r: 110, h: 195, s: 0.00045 },
    ];
    function draw() {
      t++;
      ctx.clearRect(0, 0, BASE_W, BASE_H);
      blobs.forEach((b, i) => {
        const ox = Math.sin(t * b.s * 1.2 + i) * 36;
        const oy = Math.cos(t * b.s + i * 1.7) * 28;
        const cx = BASE_W * b.x + ox;
        const cy = BASE_H * b.y + oy;
        const pulse = 0.05 + 0.02 * Math.sin(t * 0.0025 + i);
        const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, b.r);
        g.addColorStop(0, `hsla(${b.h},65%,52%,${pulse})`);
        g.addColorStop(0.55, `hsla(${b.h + 15},55%,42%,${pulse * 0.25})`);
        g.addColorStop(1, `hsla(${b.h},45%,30%,0)`);
        ctx.beginPath();
        ctx.arc(cx, cy, b.r, 0, Math.PI * 2);
        ctx.fillStyle = g;
        ctx.fill();
      });
      requestAnimationFrame(draw);
    }
    draw();
  }

  function applyScale(overlay) {
    const inner = overlay.querySelector("#tl-inner");
    if (!inner) return;
    const scale = Math.max(0.35, Math.min(overlay.offsetWidth / BASE_W, overlay.offsetHeight / BASE_H));
    inner.style.transform = `scale(${scale})`;
    inner.style.left = (overlay.offsetWidth - BASE_W * scale) / 2 + "px";
  }

  function initDrag(overlay, handle) {
    let active = false, sx, sy, sl, st;
    handle.addEventListener("mousedown", (e) => {
      if (settings.lockPosition) return;
      e.preventDefault();
      e.stopPropagation();
      active = true;
      const r = overlay.getBoundingClientRect();
      overlay.style.right = "auto";
      overlay.style.bottom = "auto";
      overlay.style.left = r.left + "px";
      overlay.style.top = r.top + "px";
      sx = e.clientX;
      sy = e.clientY;
      sl = r.left;
      st = r.top;
      resetIdle(overlay);
    });
    document.addEventListener("mousemove", (e) => {
      if (!active) return;
      overlay.style.left = sl + e.clientX - sx + "px";
      overlay.style.top = st + e.clientY - sy + "px";
    });
    document.addEventListener("mouseup", () => { active = false; });
  }

  function initResize(overlay, handle) {
    let active = false, sx, sy, sw, sh;
    handle.addEventListener("mousedown", (e) => {
      e.preventDefault();
      e.stopPropagation();
      active = true;
      sx = e.clientX;
      sy = e.clientY;
      sw = overlay.offsetWidth;
      sh = overlay.offsetHeight;
      resetIdle(overlay);
    });
    document.addEventListener("mousemove", (e) => {
      if (!active) return;
      const nw = Math.min(MAX_W, Math.max(MIN_W, sw + e.clientX - sx));
      const nh = Math.min(MAX_H, Math.max(MIN_H, sh + e.clientY - sy));
      overlay.style.width = nw + "px";
      overlay.style.height = nh + "px";
      applyScale(overlay);
    });
    document.addEventListener("mouseup", () => { active = false; });
  }

  function resetIdle(overlay) {
    if (!settings.autoHideIdle) return;
    if (idleTimer) clearTimeout(idleTimer);
    overlay.style.opacity = String(Math.max(0.2, settings.opacity / 100));
    idleTimer = setTimeout(() => {
      if (settings.autoHideIdle) overlay.style.opacity = "0.15";
    }, (settings.idleMinutes || 5) * 60 * 1000);
  }

  function applyVisualSettings(overlay) {
    if (!overlay) return;
    const op = Math.max(20, Math.min(100, settings.opacity)) / 100;
    if (!settings.autoHideIdle) overlay.style.opacity = String(op);
    const blur = Math.max(0, Math.min(40, settings.blur));
    overlay.style.backdropFilter = `blur(${blur}px) saturate(1.5)`;
    overlay.style.webkitBackdropFilter = `blur(${blur}px) saturate(1.5)`;

    const map = {
      "#tl-clock": settings.showClock,
      "#tl-pair-name": settings.showPair,
      "#tl-winrate-bar-wrap": settings.showBar,
      "#tl-winrate-text": settings.showWinrate,
      "#tl-streak-row": settings.showStreak,
      "#tl-session-row": settings.showSession,
    };
    Object.entries(map).forEach(([sel, on]) => {
      const el = overlay.querySelector(sel);
      if (el) el.style.display = on ? "" : "none";
    });

    const themes = {
      neon:  { win: "#00e99b", loss: "#ff4d6a" },
      cyber: { win: "#00d4ff", loss: "#ff2d95" },
      gold:  { win: "#f0c040", loss: "#ff7040" },
      ice:   { win: "#a0e0ff", loss: "#c080ff" },
      mono:  { win: "#e0e8f0", loss: "#9098a8" },
    };
    const th = themes[settings.theme] || themes.neon;
    const winCount = overlay.querySelector("#tl-wins");
    const lossCount = overlay.querySelector("#tl-losses");
    if (winCount) {
      winCount.style.color = th.win;
      winCount.style.textShadow = `0 0 22px ${th.win}80`;
    }
    if (lossCount) {
      lossCount.style.color = th.loss;
      lossCount.style.textShadow = `0 0 22px ${th.loss}80`;
    }
    const winAdd = overlay.querySelector(".tl-win-add");
    const lossAdd = overlay.querySelector(".tl-loss-add");
    if (winAdd) {
      winAdd.style.color = th.win;
      winAdd.style.background = th.win + "2a";
      winAdd.style.boxShadow = `inset 0 1px 0 ${th.win}35, 0 0 0 1px ${th.win}30`;
    }
    if (lossAdd) {
      lossAdd.style.color = th.loss;
      lossAdd.style.background = th.loss + "2a";
      lossAdd.style.boxShadow = `inset 0 1px 0 ${th.loss}35, 0 0 0 1px ${th.loss}30`;
    }
  }

  function openSettings(overlay) {
    const panel = overlay.querySelector("#tl-settings");
    const profitInput = overlay.querySelector("#tl-profit-input");
    if (profitInput) {
      const p = currentDayProfit();
      profitInput.value = p == null ? "" : (Math.round(p * 100) / 100).toString();
    }
    if (!panel) return;
    const opSlider = panel.querySelector("#tl-op-slider");
    const blurSlider = panel.querySelector("#tl-blur-slider");
    const stepSlider = panel.querySelector("#tl-step-slider");
    const idleSlider = panel.querySelector("#tl-idle-slider");
    if (opSlider) {
      opSlider.value = settings.opacity;
      const v = panel.querySelector("#tl-op-val");
      if (v) v.textContent = settings.opacity + "%";
    }
    if (blurSlider) {
      blurSlider.value = settings.blur;
      const v = panel.querySelector("#tl-blur-val");
      if (v) v.textContent = settings.blur + "px";
    }
    if (stepSlider) {
      stepSlider.value = settings.counterStep;
      const v = panel.querySelector("#tl-step-val");
      if (v) v.textContent = "×" + settings.counterStep;
    }
    if (idleSlider) {
      idleSlider.value = settings.idleMinutes;
      const v = panel.querySelector("#tl-idle-val");
      if (v) v.textContent = settings.idleMinutes + "m";
    }
    const toggles = {
      "tl-tog-clock": "showClock",
      "tl-tog-pair": "showPair",
      "tl-tog-bar": "showBar",
      "tl-tog-rate": "showWinrate",
      "tl-tog-streak": "showStreak",
      "tl-tog-session": "showSession",
      "tl-tog-lock": "lockPosition",
      "tl-tog-sound": "sound",
      "tl-tog-click": "clickSound",
      "tl-tog-confirm": "confirmReset",
      "tl-tog-idle": "autoHideIdle",
    };
    Object.entries(toggles).forEach(([id, key]) => {
      const el = panel.querySelector("#" + id);
      if (el) el.checked = !!settings[key];
    });
    panel.querySelectorAll(".tl-theme-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.theme === settings.theme);
    });
    panel.classList.add("open");
  }

  function closeSettings(overlay) {
    const panel = overlay.querySelector("#tl-settings");
    if (panel) panel.classList.remove("open");
  }

  function buildSettingsHTML() {
    return `
      <div id="tl-settings">
        <div id="tl-settings-header">
          <span id="tl-settings-title">Настройки</span>
          <button id="tl-settings-close" title="Закрыть">✕</button>
        </div>
        <div id="tl-settings-body">

          <div class="tl-set-group">
            <div class="tl-set-group-title">Прибыль за сегодня</div>
            <div class="tl-set-row tl-profit-row">
              <input type="text" id="tl-profit-input" class="tl-profit-input" inputmode="decimal" placeholder="0.00" autocomplete="off" />
              <button type="button" id="tl-profit-apply" class="tl-profit-apply">Сохранить</button>
            </div>
            <div class="tl-profit-hint">Плюс — заработок, минус — убыток. Старт дня пересчитается.</div>
          </div>

          <div class="tl-set-group">
            <div class="tl-set-group-title">Внешний вид</div>
            <div class="tl-set-row">
              <div class="tl-slider-wrap">
                <div class="tl-slider-top">
                  <span class="tl-set-label">Прозрачность</span>
                  <span class="tl-slider-val" id="tl-op-val">94%</span>
                </div>
                <input type="range" class="tl-slider" id="tl-op-slider" min="25" max="100" value="94" />
              </div>
            </div>
            <div class="tl-set-row">
              <div class="tl-slider-wrap">
                <div class="tl-slider-top">
                  <span class="tl-set-label">Размытие</span>
                  <span class="tl-slider-val" id="tl-blur-val">22px</span>
                </div>
                <input type="range" class="tl-slider" id="tl-blur-slider" min="0" max="36" value="22" />
              </div>
            </div>
            <div class="tl-set-row" style="flex-direction:column;align-items:stretch;">
              <span class="tl-set-label" style="margin-bottom:6px;">Тема</span>
              <div class="tl-theme-row">
                <button class="tl-theme-btn active" data-theme="neon">Neon</button>
                <button class="tl-theme-btn" data-theme="cyber">Cyber</button>
                <button class="tl-theme-btn" data-theme="gold">Gold</button>
                <button class="tl-theme-btn" data-theme="ice">Ice</button>
                <button class="tl-theme-btn" data-theme="mono">Mono</button>
              </div>
            </div>
          </div>

          <div class="tl-set-group">
            <div class="tl-set-group-title">Элементы</div>
            <div class="tl-set-row">
              <span class="tl-set-label">Пара</span>
              <label class="tl-toggle"><input type="checkbox" id="tl-tog-pair" checked /><span class="tl-toggle-track"></span></label>
            </div>
            <div class="tl-set-row">
              <span class="tl-set-label">Время</span>
              <label class="tl-toggle"><input type="checkbox" id="tl-tog-clock" checked /><span class="tl-toggle-track"></span></label>
            </div>
            <div class="tl-set-row">
              <span class="tl-set-label">Прогресс-бар</span>
              <label class="tl-toggle"><input type="checkbox" id="tl-tog-bar" checked /><span class="tl-toggle-track"></span></label>
            </div>
            <div class="tl-set-row">
              <span class="tl-set-label">Winrate</span>
              <label class="tl-toggle"><input type="checkbox" id="tl-tog-rate" checked /><span class="tl-toggle-track"></span></label>
            </div>
            <div class="tl-set-row">
              <span class="tl-set-label">Серия (streak)</span>
              <label class="tl-toggle"><input type="checkbox" id="tl-tog-streak" checked /><span class="tl-toggle-track"></span></label>
            </div>
            <div class="tl-set-row">
              <span class="tl-set-label">Время сессии</span>
              <label class="tl-toggle"><input type="checkbox" id="tl-tog-session" /><span class="tl-toggle-track"></span></label>
            </div>
          </div>

          <div class="tl-set-group">
            <div class="tl-set-group-title">Счётчик</div>
            <div class="tl-set-row">
              <div class="tl-slider-wrap">
                <div class="tl-slider-top">
                  <span class="tl-set-label">Шаг (+/−)</span>
                  <span class="tl-slider-val" id="tl-step-val">×1</span>
                </div>
                <input type="range" class="tl-slider" id="tl-step-slider" min="1" max="10" value="1" />
              </div>
            </div>
            <div class="tl-set-row">
              <span class="tl-set-label">Подтверждение сброса</span>
              <label class="tl-toggle"><input type="checkbox" id="tl-tog-confirm" checked /><span class="tl-toggle-track"></span></label>
            </div>
          </div>

          <div class="tl-set-group">
            <div class="tl-set-group-title">Поведение</div>
            <div class="tl-set-row">
              <span class="tl-set-label">Закрепить позицию</span>
              <label class="tl-toggle"><input type="checkbox" id="tl-tog-lock" /><span class="tl-toggle-track"></span></label>
            </div>
            <div class="tl-set-row">
              <span class="tl-set-label">Звук кликов</span>
              <label class="tl-toggle"><input type="checkbox" id="tl-tog-click" checked /><span class="tl-toggle-track"></span></label>
            </div>
            <div class="tl-set-row">
              <span class="tl-set-label">Звук WIN / LOSS</span>
              <label class="tl-toggle"><input type="checkbox" id="tl-tog-sound" /><span class="tl-toggle-track"></span></label>
            </div>
            <div class="tl-set-row">
              <span class="tl-set-label">Скрывать при простое</span>
              <label class="tl-toggle"><input type="checkbox" id="tl-tog-idle" /><span class="tl-toggle-track"></span></label>
            </div>
            <div class="tl-set-row">
              <div class="tl-slider-wrap">
                <div class="tl-slider-top">
                  <span class="tl-set-label">Простой (мин)</span>
                  <span class="tl-slider-val" id="tl-idle-val">5m</span>
                </div>
                <input type="range" class="tl-slider" id="tl-idle-slider" min="1" max="30" value="5" />
              </div>
            </div>
          </div>

          <div class="tl-set-group">
            <div class="tl-set-group-title">Горячие клавиши</div>
            <div class="tl-set-row"><span class="tl-set-label">WIN +</span><span class="tl-hotkey">W</span></div>
            <div class="tl-set-row"><span class="tl-set-label">LOSS +</span><span class="tl-hotkey">L</span></div>
            <div class="tl-set-row"><span class="tl-set-label">Сброс</span><span class="tl-hotkey">R</span></div>
            <div class="tl-set-row"><span class="tl-set-label">Настройки</span><span class="tl-hotkey">S</span></div>
            <div class="tl-set-row"><span class="tl-set-label">Экспорт статистики</span><span class="tl-hotkey">E</span></div>
          </div>

          <div class="tl-set-group">
            <div class="tl-set-group-title">Данные</div>
            <div class="tl-set-row" style="justify-content:center;gap:8px;">
              <button class="tl-theme-btn" id="tl-export-btn" style="flex:1;">Экспорт</button>
              <button class="tl-theme-btn" id="tl-import-btn" style="flex:1;">Импорт</button>
            </div>
            <div class="tl-set-row" style="justify-content:center;">
              <button class="tl-theme-btn" id="tl-clear-stats-btn" style="flex:1;color:#ff6b7a;">Очистить статистику</button>
            </div>
          </div>

        </div>
      </div>`;
  }

  function exportStats() {
    const data = {
      wins, losses, streak, bestStreak,
      winrate: winrate(),
      session: formatSession(),
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "yura-trade-stats.json";
    a.click();
    URL.revokeObjectURL(a.href);
  }

  function importStats() {
    const inp = document.createElement("input");
    inp.type = "file";
    inp.accept = ".json";
    inp.onchange = () => {
      const file = inp.files && inp.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const d = JSON.parse(reader.result);
          if (typeof d.wins === "number") wins = d.wins;
          if (typeof d.losses === "number") losses = d.losses;
          if (typeof d.streak === "number") streak = d.streak;
          if (typeof d.bestStreak === "number") bestStreak = d.bestStreak;
          saveStats();
          refresh();
        } catch (_) {}
      };
      reader.readAsText(file);
    };
    inp.click();
  }

  function wireSettings(overlay) {
    const profitBtn = overlay.querySelector("#tl-profit-apply");
    const profitInput = overlay.querySelector("#tl-profit-input");
    const saveProfit = () => {
      if (!profitInput) return;
      if (!applyDayProfit(profitInput.value)) {
        profitInput.classList.add("tl-profit-bad");
        setTimeout(() => profitInput.classList.remove("tl-profit-bad"), 600);
        return;
      }
      profitBtn.textContent = "Сохранено";
      setTimeout(() => { if (profitBtn) profitBtn.textContent = "Сохранить"; }, 900);
    };
    if (profitBtn) profitBtn.addEventListener("click", saveProfit);
    if (profitInput) profitInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { e.preventDefault(); saveProfit(); }
    });

    const panel = overlay.querySelector("#tl-settings");
    if (!panel) return;

    panel.querySelector("#tl-settings-close").addEventListener("click", () => closeSettings(overlay));

    const bindSlider = (id, key, valId, suffix, apply) => {
      const sl = panel.querySelector("#" + id);
      const val = panel.querySelector("#" + valId);
      if (!sl) return;
      sl.addEventListener("input", () => {
        settings[key] = +sl.value;
        if (val) val.textContent = (key === "counterStep" ? "×" : "") + settings[key] + (suffix || "");
        if (apply) apply();
        saveSettings();
      });
    };
    bindSlider("tl-op-slider", "opacity", "tl-op-val", "%", () => applyVisualSettings(overlay));
    bindSlider("tl-blur-slider", "blur", "tl-blur-val", "px", () => applyVisualSettings(overlay));
    bindSlider("tl-step-slider", "counterStep", "tl-step-val", "", null);
    bindSlider("tl-idle-slider", "idleMinutes", "tl-idle-val", "m", () => resetIdle(overlay));

    const map = {
      "tl-tog-clock": "showClock",
      "tl-tog-pair": "showPair",
      "tl-tog-bar": "showBar",
      "tl-tog-rate": "showWinrate",
      "tl-tog-streak": "showStreak",
      "tl-tog-session": "showSession",
      "tl-tog-lock": "lockPosition",
      "tl-tog-sound": "sound",
      "tl-tog-click": "clickSound",
      "tl-tog-confirm": "confirmReset",
      "tl-tog-idle": "autoHideIdle",
    };
    Object.entries(map).forEach(([id, key]) => {
      const el = panel.querySelector("#" + id);
      if (!el) return;
      el.addEventListener("change", () => {
        settings[key] = el.checked;
        applyVisualSettings(overlay);
        if (key === "autoHideIdle") resetIdle(overlay);
        saveSettings();
        refresh();
      });
    });

    panel.querySelectorAll(".tl-theme-btn[data-theme]").forEach((btn) => {
      btn.addEventListener("click", () => {
        settings.theme = btn.dataset.theme;
        panel.querySelectorAll(".tl-theme-btn[data-theme]").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        applyVisualSettings(overlay);
        saveSettings();
        refresh();
      });
    });

    const exp = panel.querySelector("#tl-export-btn");
    const imp = panel.querySelector("#tl-import-btn");
    const clr = panel.querySelector("#tl-clear-stats-btn");
    if (exp) exp.addEventListener("click", exportStats);
    if (imp) imp.addEventListener("click", importStats);
    if (clr) clr.addEventListener("click", () => {
      if (!confirm("Очистить всю статистику?")) return;
      wins = 0; losses = 0; streak = 0; bestStreak = 0;
      sessionStart = Date.now();
      saveStats();
      refresh();
    });
  }

  function buildOverlay() {
    if (document.getElementById("tl-overlay")) return;
    loadSettings();

    const overlay = document.createElement("div");
    overlay.id = "tl-overlay";
    overlay.innerHTML = `
      <canvas id="tl-canvas"></canvas>
      <div id="tl-drag-handle"><span id="tl-drag-dots">· · ·</span></div>
      <div id="tl-inner">
        <div id="tl-header">
          <span id="tl-pair-name">${currentPair}</span>
          <span id="tl-clock">${formatTime()}</span>
        </div>
        <div id="tl-label">VLDOS PRIME <span id="tl-ver">1.4</span></div>
        <div id="tl-counters">
          <div class="tl-col">
            <div class="tl-col-label">WIN</div>
            <div class="tl-count" id="tl-wins">0</div>
            <div class="tl-btns">
              <button class="tl-btn tl-win-add">+</button>
              <button class="tl-btn tl-win-sub">−</button>
            </div>
          </div>
          <div id="tl-divider"></div>
          <div class="tl-col">
            <div class="tl-col-label tl-loss-label">LOSS</div>
            <div class="tl-count tl-loss-count" id="tl-losses">0</div>
            <div class="tl-btns">
              <button class="tl-btn tl-loss-add">+</button>
              <button class="tl-btn tl-loss-sub">−</button>
            </div>
          </div>
        </div>
        <div id="tl-streak-row" class="tl-meta-row">
          <span>Streak: <b id="tl-streak">0</b></span>
          <span>Best: <b id="tl-best-streak">0</b></span>
        </div>
        <div id="tl-session-row" class="tl-meta-row" style="display:none;">
          <span>Session: <b id="tl-session">0m 00s</b></span>
        </div>
        <div id="tl-winrate-bar-wrap">
          <div id="tl-winrate-bar-bg"><div id="tl-winrate-bar-fill"></div></div>
        </div>
        <div id="tl-winrate-text">Winrate: <span id="tl-winrate-val">0.0% (0/0)</span></div>
        <div id="tl-balance">
          <div id="tl-balance-head">
            <span>БАЛАНС</span>
            <span>USD · с 00:00</span>
          </div>
          <div id="tl-balance-cols">
            <div class="tl-bal-col">
              <div class="tl-bal-label">СТАРТ</div>
              <div class="tl-bal-val" id="tl-bal-start">—</div>
            </div>
            <div id="tl-bal-div"></div>
            <div class="tl-bal-col">
              <div class="tl-bal-label">СЕЙЧАС</div>
              <div class="tl-bal-val" id="tl-bal-now">—</div>
            </div>
          </div>
          <div id="tl-bal-total"><span id="tl-bal-caption">Чистый заработок</span><span id="tl-bal-delta">—</span></div>
        </div>
        <div id="tl-footer">
          <button class="tl-footer-btn" id="tl-reset-btn"><span>↺</span> Сброс</button>
          <button class="tl-footer-btn" id="tl-settings-btn"><span>⚙</span> Настройки</button>
        </div>
      </div>
      ${buildSettingsHTML()}
      <div id="tl-resize-handle"></div>
    `;
    document.body.appendChild(overlay);

    const step = () => Math.max(1, settings.counterStep | 0);

    const addWin = () => {
      const s = step();
      wins += s;
      streak = streak >= 0 ? streak + s : s;
      if (streak > bestStreak) bestStreak = streak;
      playTone(900, 0.06);
      if (settings.sound) playTone(1100, 0.1);
      saveStats();
      refresh();
      resetIdle(overlay);
    };
    const subWin = () => {
      const s = step();
      wins = Math.max(0, wins - s);
      playTone(580, 0.05);
      saveStats();
      refresh();
      resetIdle(overlay);
    };
    const addLoss = () => {
      const s = step();
      losses += s;
      streak = streak <= 0 ? streak - s : -s;
      playTone(400, 0.07);
      if (settings.sound) playTone(260, 0.12);
      saveStats();
      refresh();
      resetIdle(overlay);
    };
    const subLoss = () => {
      const s = step();
      losses = Math.max(0, losses - s);
      playTone(500, 0.05);
      saveStats();
      refresh();
      resetIdle(overlay);
    };
    const doReset = () => {
      if (settings.confirmReset && !confirm("Сбросить счётчик WIN / LOSS?")) return;
      wins = 0;
      losses = 0;
      streak = 0;
      playTone(650, 0.08);
      saveStats();
      refresh();
      resetIdle(overlay);
    };

    overlay.querySelector(".tl-win-add").addEventListener("click", addWin);
    overlay.querySelector(".tl-win-sub").addEventListener("click", subWin);
    overlay.querySelector(".tl-loss-add").addEventListener("click", addLoss);
    overlay.querySelector(".tl-loss-sub").addEventListener("click", subLoss);
    overlay.querySelector("#tl-reset-btn").addEventListener("click", doReset);
    overlay.querySelector("#tl-settings-btn").addEventListener("click", () => openSettings(overlay));

    document.addEventListener("keydown", (e) => {
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
      const k = e.key.toLowerCase();
      if (k === "w") { e.preventDefault(); addWin(); }
      else if (k === "l") { e.preventDefault(); addLoss(); }
      else if (k === "r") { e.preventDefault(); doReset(); }
      else if (k === "s") {
        e.preventDefault();
        const panel = overlay.querySelector("#tl-settings");
        if (panel && panel.classList.contains("open")) closeSettings(overlay);
        else openSettings(overlay);
      }
      else if (k === "e") { e.preventDefault(); exportStats(); }
      else if (k === "escape") closeSettings(overlay);
    });

    document.addEventListener("mousemove", () => resetIdle(overlay), { passive: true });
    document.addEventListener("click", () => resetIdle(overlay), { passive: true });

    setInterval(() => {
      const c = document.getElementById("tl-clock");
      if (c) c.textContent = formatTime();
      const sess = document.getElementById("tl-session");
      if (sess) sess.textContent = formatSession();
      tickBalance();
    }, 1000);

    initBg(overlay);
    initDrag(overlay, overlay.querySelector("#tl-drag-handle"));
    initResize(overlay, overlay.querySelector("#tl-resize-handle"));
    wireSettings(overlay);
    applyScale(overlay);
    applyVisualSettings(overlay);
    resetIdle(overlay);
    setTimeout(() => fitPairText(overlay.querySelector("#tl-pair-name")), 50);
    refresh();
    tickBalance();
  }

  function refresh() {
    const winsEl = document.getElementById("tl-wins");
    const lossesEl = document.getElementById("tl-losses");
    const rateEl = document.getElementById("tl-winrate-val");
    const fill = document.getElementById("tl-winrate-bar-fill");
    const stEl = document.getElementById("tl-streak");
    const bestEl = document.getElementById("tl-best-streak");
    if (!winsEl || !lossesEl || !rateEl || !fill) return;
    winsEl.textContent = wins;
    lossesEl.textContent = losses;
    rateEl.textContent = winrate();
    rateEl.style.color = winrateColor();
    const pct = wins + losses === 0 ? 0 : (wins / (wins + losses)) * 100;
    fill.style.width = pct + "%";
    fill.style.background = winrateColor();
    if (stEl) {
      stEl.textContent = streak > 0 ? "+" + streak : String(streak);
      stEl.style.color = streak > 0 ? "#00e99b" : streak < 0 ? "#ff4d6a" : "";
    }
    if (bestEl) bestEl.textContent = bestStreak;
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => { buildOverlay(); startPairWatcher(); });
  } else {
    buildOverlay();
    startPairWatcher();
  }
})();
